#include<iostream>
#include<stdio.h>
#include<string.h>    //strlen
#include<stdlib.h>    //strlen
#include<sys/socket.h>
#include<arpa/inet.h> //inet_addr
#include<unistd.h>    //write
#include<pthread.h>

#define AddressFamily_InterNetwork AF_INET
#define SocketType_Stream SOCK_STREAM
#define ProtocolType_TCP 0
#define IPAddress_Any INADDR_ANY
#define SocketFlags_None 0
#define Thread pthread_t

using namespace std;

void *connection_handler(void *);

int main()
{
    int ServerSocket, ClientSocket, c, read_size, port, *new_sock;
    struct sockaddr_in server, client; //Declaring variables server and client
    char buffer[256]; //Bytes received data
    char IsConnect = false;

    cout << "SERVIDOR" << endl;
    ServerSocket = socket(AddressFamily_InterNetwork, SocketType_Stream, ProtocolType_TCP);
    if (ServerSocket == -1) //Tratando erro 1
    {
        cout << "Erro: Nao foi possivel criar soquete" << endl;
    }
    cout << "Soquete criado..." << endl;
    //Preparando estrutura sockaddr_in

    cout << "Digite a porta: ";
    cin >> port;
    cout << endl;
    server.sin_family = AddressFamily_InterNetwork;
    server.sin_addr.s_addr = IPAddress_Any;
    server.sin_port = htons(port);

    //Bind
    if (bind(ServerSocket, (struct sockaddr *) &server, sizeof(server)) < 0) //Comando Bind no servidor e tratando erro 2
    {
        cout << "Erro: Comando Bind falhou." << endl;
        exit(1);
    }
    cout << "Comando Bind carregado" << endl;
    //Listen
    listen(ServerSocket, 3);
    cout << "Aguardando cliente" << endl;
    //Accept connection
    while(ClientSocket = accept(ServerSocket, (struct sockaddr*) &client, (socklen_t*) &c))
    {
        cout << "Conectado." << endl;
        Thread t;
        new_sock =(int*)malloc(1);
        *new_sock = ClientSocket;
        if((pthread_create(&t, NULL, connection_handler, (void*)new_sock)) < 0)//Tratando erro 3
        {
            cout << "Erro: Nao foi possivel criar Thread para o cliente." << endl;
            exit(1);
        }
        cout << "Manipulador acessado." << endl;

    }
} //END MAIN

    void *connection_handler(void *ServerSocket)
    {

    }
