#include<iostream>
#include<stdio.h>
#include<string.h>    //strlen
#include<stdlib.h>    //strlen
#include<sys/socket.h>
#include<arpa/inet.h> //inet_addr
#include<unistd.h>    //write

#define AddressFamily_InterNetwork AF_INET
#define SocketType_Stream SOCK_STREAM
#define ProtocolType_TCP 0
#define IPAddress_Any INADDR_ANY
#define SocketFlags_None 0

using namespace std;


int main()
{
    int ServerSocket, ClientSocket, c, read_size, port;
    struct sockaddr_in server, client; //Declaring variables server and client
    char buffer[256]; //Bytes received data
    char IsConnect = false;

    cout << "SERVIDOR" << endl;
    ServerSocket = socket(AddressFamily_InterNetwork, SocketType_Stream, ProtocolType_TCP);
    if (ServerSocket == -1) //Tratando erro 1
    {
        cout << "Erro: Nao foi possivel criar soquete" << endl;
    }
    cout << "Soquete criado..." << endl;
    //Preparando estrutura sockaddr_in

    cout << "Digite a porta: ";
    cin >> port;
    cout << endl;
    server.sin_family = AddressFamily_InterNetwork;
    server.sin_addr.s_addr = IPAddress_Any;
    server.sin_port = htons(port);

    //Bind
    if (bind(ServerSocket, (struct sockaddr *) &server, sizeof(server)) < 0) //Comando Bind no servidor e tratando erro 2
    {
        cout << "Erro: Comando Bind falhou." << endl;
        exit(1);
    }
    cout << "Comando Bind carregado" << endl;
    //Listen
    listen(ServerSocket, 3);
    cout << "Aguardando cliente" << endl;
    //Accept connection
    ClientSocket = accept(ServerSocket, (struct sockaddr*) &client, (socklen_t*) &c);
    if (ClientSocket < 0) //Tratando erro 3
    {
        cout << "Erro: Conectividade falhou." << endl;
        exit(1);
    }
        IsConnect = true;
        cout << "Conectado." << endl;

    while(IsConnect)
    {
        //Start loopback data
        read_size = recv(ClientSocket, buffer, sizeof(buffer), SocketFlags_None);
        if (read_size <= 0) break; //Saindo do loop caso a conexao for desfeita
        cout << "Cliente: " << buffer << endl;
        write(ClientSocket, buffer, strlen(buffer));
        //Finish loopback data
        memset(buffer, 0, sizeof(buffer)); //Limpando buffer para nao haver acumulo de bytes --> 0 para index, sideof() equivale a "string.length"
    }

    cout << "read_size = " << read_size << endl;

    if (read_size == 0)
    {
        IsConnect = false;
        cout << "Cliente desconectado" << endl;
        fflush(stdout);
    }
    if (read_size == -1) //Tratando erro 4
    {
        IsConnect = false;
        cout << "Erro: Falha ao receber bytes." << endl;
        exit(1);
    }
    return 0;
}
