/*
    Simple udp server
*/
#include<iostream>
#include<stdio.h> //printf
#include<string.h> //memset
#include<stdlib.h> //exit(0);
#include<arpa/inet.h>
#include<sys/socket.h>
#include<pthread.h>

#define Thread pthread_t
#define BUFLEN 512  //Max length of buffer
#define PORT 8888   //The port on which to listen for incoming data

struct sockaddr_in si_me, si_other;
int s, i, recv_len;
int slen = sizeof(si_other);

void SendUDP(int _socket)
{

}

void *RecvUDP(void *x)
{
    printf("recv entrou");
    char buf[BUFLEN];
    while(1)
    {
        printf("Waiting for data...");
        fflush(stdout);
        memset(buf, 0, sizeof(buf)); //Limpando buffer para nao haver acumulo de bytes --> 0 para index, sideof() equivale a "string.length"
        //try to receive some data, this is a blocking call
        if ((recv_len = recvfrom(s, buf, BUFLEN, 0, (struct sockaddr *) &si_other, (socklen_t*)&slen)) == -1)
        {
            printf("recvfrom()");
        }

        //print details of the client/peer and the data received
        printf("Received packet from %s:%d\n", inet_ntoa(si_other.sin_addr), ntohs(si_other.sin_port));
        printf("Data: %s\n" , buf);

    }
}
int main(void)
{
    int *x = 0;
    //create a UDP socket
    if ((s=socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) == -1)
    {
        printf("socket");
    }

    // zero out the structure
    memset((char *) &si_me, 0, sizeof(si_me));

    si_me.sin_family = AF_INET;
    si_me.sin_port = htons(PORT);
    si_me.sin_addr.s_addr = htonl(INADDR_ANY);

    //bind socket to port
    if( bind(s , (struct sockaddr*)&si_me, sizeof(si_me) ) == -1)
    {
        printf("bind");
    }
    printf("SERVIDOR ABERTO\n");
        Thread t_send;
        Thread t_recv;
        if((pthread_create(&t_recv, NULL, RecvUDP, (void*)(intptr_t)x)) < 0)
        {
            printf("thread t_recv error");
        }


    printf("send entrou");
    char buf1[BUFLEN];
    while(1)
    {
        std::cin >> buf1;

                //now reply the client with the same data
        if (sendto(s, buf1, BUFLEN, 0, (struct sockaddr*) &si_other, slen) == -1)
        {
            printf("sendto()");
        }
    }


    printf("FIM DO PROGRAMA");
    return 0;
}
