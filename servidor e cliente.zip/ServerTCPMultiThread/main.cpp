#include<iostream>
#include<vector>
#include<string>
#include<stdio.h>
#include<string.h>    //strlen
#include<stdlib.h>    //strlen
#include<sys/socket.h>
#include<arpa/inet.h> //inet_addr
#include<unistd.h>    //write
#include<pthread.h>

#define AddressFamily_InterNetwork AF_INET
#define SocketType_Stream SOCK_STREAM
#define ProtocolType_TCP 0
#define IPAddress_Any INADDR_ANY
#define SocketFlags_None 0
#define Thread pthread_t

using namespace std;

vector<int> vectorsocket;
int CountClients;
void *connection_handler(void *);
void *SendForAll(void *);

int main()
{
    int ServerSocket, ClientSocket, c, port, *new_sock;
    struct sockaddr_in server, client; //Declaring variables server and client
    char IsConnect = false;

    cout << "SERVIDOR" << endl;
    ServerSocket = socket(AddressFamily_InterNetwork, SocketType_Stream, ProtocolType_TCP);
    if (ServerSocket == -1) //Tratando erro 1
    {
        cout << "Erro: Nao foi possivel criar soquete" << endl;
    }
    cout << "Soquete criado..." << endl;

    //Preparando estrutura sockaddr_in
    cout << "Digite a porta: ";
    cin >> port;
    cout << endl;

    memset(&server, 0, sizeof (server)); //Zera estrutura para evitar erros
    server.sin_family = AddressFamily_InterNetwork;
    server.sin_addr.s_addr = IPAddress_Any;
    server.sin_port = htons(port);

    //Bind
    if (bind(ServerSocket, (struct sockaddr *) &server, sizeof(server)) < 0) //Comando Bind no servidor e tratando erro 2
    {
        cout << "Erro: Comando Bind falhou." << endl;
        exit(1);
    }
    cout << "Comando Bind carregado" << endl;
    //Listen
    listen(ServerSocket, 1);
    cout << "Aguardando cliente" << endl;
    //Accept connection
    while(ClientSocket = accept(ServerSocket, (struct sockaddr*) &client, (socklen_t*) &c))
    {
        cout << "Conectado." << endl;
        Thread t;
        Thread s;
        new_sock =(int*)malloc(1);
        *new_sock = ClientSocket;
        vectorsocket.push_back(ClientSocket);
        CountClients = vectorsocket.size();
        cout << "Total de clientes: " << vectorsocket.size() << endl;
        if((pthread_create(&t, NULL, connection_handler, (void*)new_sock)) < 0)//Tratando erro 3
        {
            cout << "Erro: Nao foi possivel criar Thread para o cliente." << endl;
            exit(1);
        }

        if((pthread_create(&s, NULL, SendForAll, (void*)new_sock)) < 0)//Tratando erro 3
        {
            cout << "Erro: Nao foi possivel criar thread-1." << endl;
            exit(1);
        }
        cout << "Manipulador acessado." << endl;
    }
    if(ClientSocket < 0) //Tratando erro 4
    {
        cout << "Erro: Aceitamento falhou." << endl;
        exit(1);
    }
    return 0;
} //END MAIN


void *SendForAll(void *)
{
    char data[256];
    while(true)
    {
        cin >> data;

            for(int i = 0; i < vectorsocket.size(); i++)
            {
                int temp = vectorsocket[i];
                write(temp , data , strlen(data));
                memset(data, 0, sizeof(data)); //Limpando buffer para nao haver acumulo de bytes --> 0 para index, sideof() equivale a "string.length"
            }
    }
}

void *connection_handler(void *ServerSocket)
{
    cout << "Entrou na thread" << endl;
    //Armazena informacoes do socket
    int sock = *(int*)(ServerSocket);
    int read_size;
    char buffer[256];

    memset(buffer, 0, sizeof(buffer)); //Limpando buffer para nao haver acumulo de bytes --> 0 para index, sideof() equivale a "string.length"
    //Receive a message from client
    while((read_size = recv(sock, buffer, 256, SocketFlags_None)) > 0)
    {

        cout << "read_size = " << read_size << endl;
        cout << "Cliente: " << buffer << endl;
        memset(buffer, 0, sizeof(buffer)); //Limpando buffer para nao haver acumulo de bytes --> 0 para index, sideof() equivale a "string.length"

    }

    if(read_size == 0)
    {
        puts("Client disconnected");


    //INICIO...............................


     //FIM...............................


        fflush(stdout);
    }

    else if(read_size == -1) //Tratando erro 5
    {
        cout << "recv failed" << endl;
        free(ServerSocket);
        exit(1);
    }

    //Free the socket pointer
    free(ServerSocket);
    return 0;
}
