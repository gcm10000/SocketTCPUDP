#include<iostream>
#include<vector>
#include<stdio.h>
#include<stdlib.h>
using namespace std;


void Vector_Remove(vector<int> _vector)
{
    int x = 0;
    for(int i = 0; i < _vector.size(); i++)
    {
        if (sock == _vector[i]){
            x = i;
            break;
        }
    }

    for(int y = x; y < _vector.size(); y++)
    {
    _vector[y] = _vector[y+1];
    }
    _vector.pop_back();
}

int main (int argc, char* argv[])
{
    vector<int> vectorsocket;
    vectorsocket.push_back(0);
    vectorsocket.push_back(5);
    vectorsocket.push_back(10);
    vectorsocket.push_back(20);

        int vetor[100] = {0,5,10,20,30, -42}; // preeencher vetor com scanf
        int vetor1[3];

        vetor1[0] = 1;
        vetor1[1] = 2;
        vetor1[2] = 3;

        for(int x = 0; x < 3; x++){
        vetor1[x] = vetor1[x+1];
        }
        //vectorsocket[3] = 0;

        for(int x = 0; x < 3; x++){
        cout << vetor1[x] << endl;
        }


    return 0;
}


